using Microsoft.EntityFrameworkCore;

namespace Artyfy.Dal.Context
{
    public class ArtyfyContextPartial : DbContext
    {
    }
}