using Microsoft.EntityFrameworkCore;

namespace Deneme.Dal.Context
{
    public class DenemeContextPartial : DbContext
    {
    }
}