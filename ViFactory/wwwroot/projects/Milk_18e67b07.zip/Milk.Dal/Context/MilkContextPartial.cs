using Microsoft.EntityFrameworkCore;

namespace Milk.Dal.Context
{
    public class MilkContextPartial : DbContext
    {
    }
}