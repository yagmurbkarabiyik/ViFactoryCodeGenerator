using Microsoft.EntityFrameworkCore;

namespace IceTea.Dal.Context
{
    public class IceTeaContextPartial : DbContext
    {
    }
}