using Microsoft.EntityFrameworkCore;

namespace Coffee.Dal.Context
{
    public class CoffeeContextPartial : DbContext
    {
    }
}