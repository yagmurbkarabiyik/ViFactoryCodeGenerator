using Microsoft.EntityFrameworkCore;

namespace Mst.Dal.Context
{
    public class MstContextPartial : DbContext
    {
    }
}