using System.Reflection;
using System.Xml.Linq;

class Program
{
	 static void Main()
	 {
		
	 }

}