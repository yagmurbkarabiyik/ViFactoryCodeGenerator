using Microsoft.EntityFrameworkCore;

namespace Tea.Dal.Context
{
    public class TeaContextPartial : DbContext
    {
    }
}